<?php
echo $_POST["cedula"];
echo $clave;
echo "hola mundo";


?>