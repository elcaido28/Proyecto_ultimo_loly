<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <style media="screen">
    *{ margin: 0; padding: 0; }
      .fondotodo{
        width: 100%;
        height: 100vh;
        background-image: url(images/nosotros.jpg);
        background-size: cover;
        /* background-position: 0px 0px;
        background-repeat: no-repeat; */
      }
    </style>
    <div class="fondotodo"></div>
  </body>
</html>
