<?php
 $host = "localhost";
 $user = "";
 $password = "";
 $bd = "loly";

 $conectar = mysqli_connect($host,$user,$clave,$bd)

  ?>